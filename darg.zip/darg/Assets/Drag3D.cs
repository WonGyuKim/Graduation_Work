﻿using UnityEngine;
using System.Collections;

public class Drag3D : MonoBehaviour
{

    Camera _mainCam = null;
    private bool _mouseState;
    private GameObject target;
    private Vector3 MousePos;
    void Awake()
    {
        _mainCam = Camera.main;
    }

    // Update is called once per frame 
    void Update()
    {

        // Debug.Log(_mouseState); 
        if (Input.GetMouseButtonDown(0))
        {

            RaycastHit hitInfo;
            target = GetClickedObject(out hitInfo);
            if (target != null)
            {
                _mouseState = true;
                MousePos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, -Camera.main.transform.position.z));
                target.transform.position = new Vector3(MousePos.x, MousePos.y, target.transform.position.z);
            }
        }
        if (Input.GetMouseButtonUp(0))
        {
            _mouseState = false;
        }
        if (_mouseState)
        {
            MousePos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, -Camera.main.transform.position.z));
            target.transform.position = new Vector3(MousePos.x, MousePos.y, target.transform.position.z);
        }

    }
    GameObject GetClickedObject(out RaycastHit hit)
    {
        GameObject target = null;
        Ray ray = _mainCam.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray.origin, ray.direction * 10, out hit))
        {
            target = hit.collider.gameObject;
        }

        return target;
    }

}